import React from "react";
import LibraryManagement from "./components/LibraryManagement";

function App() {
  return (
    <div>
      <LibraryManagement />
    </div>
  );
}

export default App;
